package com.store.films;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
