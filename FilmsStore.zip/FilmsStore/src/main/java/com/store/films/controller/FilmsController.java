package com.store.films.controller;


import com.store.films.entity.FilmEntity;
import com.store.films.service.FilmsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/stores-films")
public class FilmsController {

    @Autowired
    FilmsService filmsService;

    @GetMapping(value = "/{id}")
    public ResponseEntity<FilmEntity> getFilm(@PathVariable("id") long id){
        log.info("Buscando pelicula con id {}", id);
        FilmEntity currentFilm = filmsService.getFilm(id);
        if (currentFilm == null){
            log.error("Problema en el proceso de busqueda. Pelicula con el id {} no encontrada", id);
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(currentFilm);
    }

    @PostMapping
    public ResponseEntity<FilmEntity> createFilm(@RequestBody FilmEntity film){
        log.info("Creando pelicula: {}", film);
        FilmEntity filmDB = filmsService.createFilm(film);
        return ResponseEntity.status(HttpStatus.CREATED).body(filmDB);
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<FilmEntity> updateFilm(@PathVariable("id") long id, @RequestBody FilmEntity film){
        log.info("Editando pelicula con id {}", id);
        film.setId(id);
        FilmEntity currentFilm = filmsService.updateFilm(film);
        if (currentFilm == null){
            log.error("Problema en la actualización. Pelicula con el id {} no encontrada", id);
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(currentFilm);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<FilmEntity> deleteFilm(@PathVariable("id") long id){
        log.info("Buscando y borrando pelicula con id {}", id);
        FilmEntity currentFilm = filmsService.getFilm(id);
        if (currentFilm == null){
            log.error("Problema en el proceso de borrado. Pelicula con el id {} no encontrada", id);
            return ResponseEntity.notFound().build();
        }
        currentFilm = filmsService.deleteFilm(currentFilm);
        return ResponseEntity.ok(currentFilm);
    }
}
