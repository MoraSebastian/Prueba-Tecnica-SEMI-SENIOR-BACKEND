package com.store.films.service;

import com.store.films.entity.FilmEntity;
import com.store.films.repository.FilmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FilmsServiceImpl implements FilmsService{

    @Autowired
    FilmRepository filmRepository;

    @Override
    public FilmEntity createFilm(FilmEntity film) {
        FilmEntity filmDB = filmRepository.findById(film.getId()).orElse(null);
        if ( filmDB != null ){
            return filmDB;
        }
        filmDB = filmRepository.save(film);

        filmDB = filmRepository.save(film);
        return filmDB;
    }

    @Override
    public FilmEntity updateFilm(FilmEntity film) {
        FilmEntity filmDB = filmRepository.findById(film.getId()).orElse(null);
        if (filmDB == null){
            return null;
        }
        filmDB.setDescription( film.getDescription() );
        filmDB.setDuration( film.getDuration() );
        filmDB.setRating( film.getRating() );
        filmDB.setYear( film.getYear() );
        filmDB.setTitle( film.getTitle() );
        filmDB.setRental_price( film.getRental_price() );
        filmRepository.save(filmDB);
        return null;
    }

    @Override
    public FilmEntity deleteFilm(FilmEntity film) {
        FilmEntity filmDB = filmRepository.findById(film.getId()).orElse(null);
        if( filmDB == null ){
            return null;
        }
        filmRepository.delete(filmDB);
        return filmDB;
    }

    @Override
    public FilmEntity getFilm(Long id) {
        FilmEntity filmDB = filmRepository.findById(id).orElse(null);
        return filmDB;
    }
}
