package com.store.films.service;

import com.store.films.entity.FilmEntity;

public interface FilmsService {

    public FilmEntity createFilm(FilmEntity film);

    public FilmEntity updateFilm(FilmEntity film);

    public FilmEntity deleteFilm(FilmEntity film);

    public FilmEntity getFilm(Long id);

}
