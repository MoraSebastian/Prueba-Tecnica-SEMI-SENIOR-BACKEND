DROP TABLE IF EXISTS tbl_category;

CREATE TABLE tbl_category (
                                category_id BIGINT AUTO_INCREMENT  PRIMARY KEY,
                                name VARCHAR(250) NOT NULL,
                                description VARCHAR(250) NOT NULL,
);


DROP TABLE IF EXISTS tbl_film;

CREATE TABLE tbl_film (
                              film_id BIGINT AUTO_INCREMENT  PRIMARY KEY,
                              title VARCHAR(250) NOT NULL,
                              description VARCHAR(250) NOT NULL,
                              yearfilm VARCHAR(250) NOT NULL,
                              rental_duration VARCHAR(250) NOT NULL,
                              rating VARCHAR(250),
                              duration BIGINT NOT NULL,
                              rental_price VARCHAR(250)
);